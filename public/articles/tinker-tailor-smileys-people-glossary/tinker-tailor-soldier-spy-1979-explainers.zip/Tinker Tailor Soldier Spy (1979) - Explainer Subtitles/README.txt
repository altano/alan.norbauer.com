Explainer Subtitles — Tinker Tailor Soldier Spy (1979)
======================================================

These subtitle tracks add short, plain-English definitions the moment a term a
modern viewer might not know is spoken -- Britishisms, dated words, and Cold War
spy jargon (e.g. "lamplighters -- the Circus surveillance & watcher teams").

Two kinds of track are included:

  Explainers - definitions only
        A supplementary track: ONLY the pop-up definitions, nothing else. Turn it
        on alongside the picture (with the show's own subtitles off) to get the
        definitions without doubling up the dialogue.

  English + Explainers
        The full English dialogue subtitle with the definitions folded in -- each
        one shown in [square brackets] under the line that triggers it. Use this
        as your single subtitle track if you also want the dialogue subtitled.

...and each comes in two formats:

  ass/  Advanced SubStation Alpha -- the intended look (small, centered, lightly
        boxed). Best in mpv, MPC-HC, PotPlayer, Kodi, Infuse, and IINA. In VLC,
        set the video output to OpenGL or the styling may not render.
  srt/  SubRip -- the most widely compatible format (virtually every player, phone,
        smart TV, and media server), but without the custom positioning/styling.

How to use as a sidecar file
----------------------------
Rename the file to match your video file, drop it in the same folder, then pick
the track in your player. Example:

  My.Episode.mkv
  My.Episode.ass      (or)   My.Episode.srt

Sync note: These are timed to the UK release of Tinker Tailor Soldier Spy (1979) (7 parts). On another
release the timing may differ, so you may need to shift the track in your player.
