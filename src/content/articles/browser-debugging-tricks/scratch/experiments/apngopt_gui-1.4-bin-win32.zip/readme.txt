  APNG Optimizer 1.4

  Optimizes APNG animations.

  https://sourceforge.net/projects/apng/files/APNG_Optimizer/

  Copyright (c) 2011-2015 Max Stepin
  maxst@users.sourceforge.net

  License: zlib license

--------------------------------

  Usage:

apngopt [options] anim.png [anim_opt.png]

  Options:

-z0  : zlib compression
-z1  : 7zip compression (default)
-z2  : zopfli compression
-i## : number of iterations, default -i15

--------------------------------

  Changes in version 1.4:

- Codebase updated (based on apngdis 2.8, apngasm 2.9)


  Changes in version 1.3:

- Codebase updated (based on apngdis 2.7, apngasm 2.9)
- Added 7zip and Zopfli compression options.


  Changes in version 1.2:

- Codebase updated (based on apngdis 2.5, apngasm 2.7)
- Optimization: join identical frames


  Changes in version 1.1:

- Codebase updated (based on apngdis 2.4, apngasm 2.5)
- Better optimization
- zlib license


  Changes in version 1.0:

- Initial release (based on apngdis 2.3, apngasm 2.3)


