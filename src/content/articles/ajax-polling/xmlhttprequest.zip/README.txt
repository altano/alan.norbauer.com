XMLHTTPRequest Polling
By Alan Nouri and Adam Podolnick
http://www.dubi.org/ajax-polling
---------------------------------------------------------------------------
Feel free to modify or redistribute this code, but please leave this
notice and the credits intact.