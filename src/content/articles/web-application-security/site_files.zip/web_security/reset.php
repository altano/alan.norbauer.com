<?php

    /* RESETS THE DATABASE - TRUNCATES ALL THE TABLES AND ADDS BACK IN DATA */

    require_once 'include/Database.php';
    
    $db = new Database;
    
    /* TABLE: Messages */
    $db->query( "TRUNCATE TABLE Messages;" );
    $sql = "INSERT INTO Messages (Name,Message) VALUES ('Jack','Hello people of the interweb!'), ";
    $sql .=     "('Fred','Hey Jack what is up'), ";
    $sql .=     "('Amy','Hmm, I am upset'), ";
    $sql .=     "('Fred','What is wrong?'), ";
    $sql .=     "('Amy','Your face!'), ";
    $sql .=     "('Sam','Oh snap!'); ";
    $db->query( $sql );
		
    /* TABLE: Staff */
    $db->query( "TRUNCATE TABLE Staff;" );
    $sql = "INSERT INTO Staff (Name, Pin) VALUES ('Jack', 3521), ";
    $sql .=     "('Fred', 32854), ";
    $sql .=     "('Amy', 19823), ";
    $sql .=     "('Sam', 1293); ";
    $db->query( $sql );
    
    $db->disconnect();
    
    header( 'Location: vulnerable.php' );    
?>