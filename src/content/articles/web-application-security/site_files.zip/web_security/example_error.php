<?php
	mysql_connect( "mysql.terriblefish.com" );
?>