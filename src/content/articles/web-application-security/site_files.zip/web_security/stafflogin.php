<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>SQL Injection</title>

<body>
<?php
	require_once 'include/Database.php';
	
	$db = new Database;
	
	$result = $db->query( "SELECT * FROM Staff WHERE Name='${_GET['name']}' AND Pin=${_GET['pin']}" );
	
	if( $result->queryCount == 1 ) {
		echo "<p>Login successful!</p>\n";
	}
	else {
		echo "<p>Login failed!</p>\n";
	}
?>

</body>
</html>
