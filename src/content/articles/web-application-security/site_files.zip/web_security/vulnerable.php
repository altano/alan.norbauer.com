<?php
    /* The details of how the Database class works is irrelivant
      at this point, but if you want to learn more PHP, sitepoint.com
      is a good place to start */
    require_once 'include/Database.php';
    
    $db = new Database;
    
    /* Checks for form input.  If a form has been submitted, it adds the info
      to the Database. */
    if (isset($_POST['name'])) {
        /* Grab the name and message from the form with no validation */
        $name = $_POST['name'];
        $message = $_POST['message'];
        
        /* Insert into DB */
        $db->query( "INSERT INTO Messages (Name, Message) VALUES ('$name', '$message')" );
    }
    
    /* GET ALL THE MESSAGES FOR DISPLAY */
    $messages = $db->query( "SELECT Name, Message FROM Messages ORDER BY DateAdded" );
    
    $db->disconnect();    
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unvalidated Input</title>
</head>

<body>
    <h1>&lt;vulnerable.php&gt</h1>
    <a href="reset.php">reset the database</a>
    <hr />
    
    <h2>Add a message</h2>
    <form method="post" action="vulnerable.php">
        Name: <input type="text" name="name" /><br />
        Message: <input type="text" name="message" /><br />
        <input type="submit" value="Submit" />
    </form>
    <hr />
    
    <h2>Current messages</h2>
    <ul>
    <?php
        while ($message = $messages->fetch()) {
            echo "<li>${message['Name']}: ${message['Message']}</li>\n";
        }
    ?>
    </ul>
    
</body>
</html>
