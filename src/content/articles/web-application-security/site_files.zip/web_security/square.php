<?php
/* This code is necessary because my webhost has magic_quotes_gpc turned on and I
	cannot override it.  This basically escapes all quotes in the get, post, and cookie
	arrays.  This can be good if its turned on, but you can't rely on it always being on,
	so it's important to safeguard your apps from unescaped quotes! */

	function StripAllSlashes (&$ArrayGET, $Value) 
	{ 
		if (is_array ($ArrayGET)) array_walk ($ArrayGET, "StripAllSlashes"); 
		else $ArrayGET = stripslashes ($ArrayGET); 
	} 
	if (isset ($_GET) && get_magic_quotes_gpc ()) array_walk ($_GET, "StripAllSlashes");
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>XSS</title>

<script></script>

</head>
<body>
<?php
	if( intval($_GET['num']) ) {
		$square = $_GET['num'] * $_GET['num'];
		echo $square;
	}
	else
		echo $_GET['num'] . " is not a number!";
?>
</body>
</html>
