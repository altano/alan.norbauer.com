<?php
		
	function fatal_error($str = '') {
		if (!empty($str)) {
			echo $str;
			exit( 1 );
		}
	}
	
	class Database {

		var $host;
		var $dbUser;
		var $dbPass;
		var $dbName;
		
		var $dbConn;
		var $connectError;

		function Database()	{
			$this->host = 'xxxx';	# location of MySQL host
			$this->dbUser = 'xxxx';
			$this->dbPass = 'xxxx';
			$this->dbName = 'xxxx'; # websecDB or whatever you name the db
			$this->connect();
		}
		
		function connect() {
			// Make connection to MySQL server
			if (!($this->dbConn = @mysql_connect($this->host,
				$this->dbUser, $this->dbPass)))
			{
				fatal_error( 'Connecting to SQL server' );
				$this->connectError = true;
			}
			// Select database
			else if (!@mysql_select_db($this->dbName,$this->dbConn))
			{
				fatal_error( 'Selecting database' );
				$this->connectError = true;
			}
		}
		
		function disconnect() {
			if( $this->dbConn ) {
				return @mysql_close($this->dbConn);
			}
			else {
				return false;
			}
		}

		function isError() {
			if ($this->connectError) {
				return true;
			}
			$error = mysql_error($this->dbConn);
			if (empty($error)) {
				return false;
			}
			else {
				return true;
			}
		}

		function &unbuffered_query($sql) {
			if (!($queryResource = @mysql_unbuffered_query($sql, $this->dbConn))) {
				fatal_error( 'Query failed: ' . mysql_error($this->dbConn) . ' SQL: ' . $sql );
			}
			
			return new MySQLResult($this, $queryResource);
		}
		
		function &query($sql) {
			if (!($queryResource = @mysql_query($sql, $this->dbConn))) {
				fatal_error( 'Query failed: ' . mysql_error($this->dbConn) . ' SQL: ' . $sql );
			}
			
			return new MySQLResult($this, $queryResource);
		}
	}

	class MySQLResult {
		var $mysql;
		var $query;
		var $queryCount;
		
		function MySQLResult(&$mysql, $query) 
		{
			$this->mysql = &$mysql;
			$this->query = $query;
			$this->queryCount = mysql_affected_rows();
		}

		function fetch() 
		{
			$row = mysql_fetch_array($this->query, MYSQL_ASSOC);
			if ( $row ) {
				return $row;
			}
			else {
				return false;
			}
		}

		function isError()
		{
			return $this->mysql->isError();
		}
	}
	
?>
